-- MySQL dump 10.13  Distrib 5.7.16, for Win64 (x86_64)
--
-- Host: 163.172.69.8    Database: projectagora_db
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_terms`
--

LOCK TABLES `wp_terms` WRITE;
/*!40000 ALTER TABLE `wp_terms` DISABLE KEYS */;
INSERT INTO `wp_terms` VALUES (3,'Publishers','publishers',0),(6,'Header_Menu_Mobile','header_menu_mobile',0),(7,'Header_Menu_Center','header_menu_center',0),(13,'Uncategorized','uncategorized-el',0),(15,'EN','en',0),(16,'EN','pll_en',0),(17,'pll_5c93751c5af8e','pll_5c93751c5af8e',0),(19,'pll_5c9375281ae8e','pll_5c9375281ae8e',0),(20,'AR','ar',1),(21,'AR','pll_ar',0),(22,'Uncategorized','uncategorized-ar',0),(25,'Header_Menu_Right','header_menu_right',0),(32,'Cases-Pu','cases-pu',0),(33,'pll_5c9ccc3da2ad8','pll_5c9ccc3da2ad8',0),(35,'Footer_Publishers_Menu','footer_publishers_menu',0),(36,'Footer_Advertisers_Menu','footer_advertisers_menu',0),(37,'Footer_OurCompany_Menu','footer_ourcompany_menu',0),(38,'Footer_Gallery_Menu','footer_gallery_menu',0),(39,'Footer_Legal_Menu','footer_legal_menu',0),(40,'Advertisers','advertisers',0),(41,'pll_5cab3be34771c','pll_5cab3be34771c',0),(42,'Cases-Ad','cases-ad',0),(43,'pll_5cab3c0e9a411','pll_5cab3c0e9a411',0),(44,'Questions-Ad','questions-ad',0),(45,'pll_5cadabd085398','pll_5cadabd085398',0),(46,'Questions-Pu','questions-pu',0),(47,'pll_5cadac3716790','pll_5cadac3716790',0),(48,'News','news',0),(49,'pll_5cdbe9cfcbea6','pll_5cdbe9cfcbea6',0),(50,'Business','business',0),(51,'pll_5cdbe9cfd8007','pll_5cdbe9cfd8007',0),(56,'pll_5ce69cefee849','pll_5ce69cefee849',0),(57,'Header_Menu_Right_Arabic','header_menu_right_arabic',0),(58,'Header_Menu_Center_Arabic','header_menu_center_arabic',0),(59,'Header_Menu_Mobile_Arabic','header_menu_mobile_arabic',0),(60,'pll_5ce7beb62bb8e','pll_5ce7beb62bb8e',0),(61,'pll_5ce7c3f5aaae6','pll_5ce7c3f5aaae6',0),(62,'Footer_OurCompany_Menu_Arabic','footer_ourcompany_menu_arabic',0),(64,'pll_5ce7e7bf8f406','pll_5ce7e7bf8f406',0),(65,'pll_5ce7fe655ae2b','pll_5ce7fe655ae2b',0),(66,'pll_5ce80881c8141','pll_5ce80881c8141',0),(67,'pll_5ce808c3555ea','pll_5ce808c3555ea',0),(68,'pll_5ceb94a2c2edb','pll_5ceb94a2c2edb',0),(69,'pll_5cee5ac1b83db','pll_5cee5ac1b83db',0),(70,'pll_5cee5c15e38eb','pll_5cee5c15e38eb',0),(71,'pll_5cee5d03a08c4','pll_5cee5d03a08c4',0),(72,'pll_5cee5e132d268','pll_5cee5e132d268',0),(73,'pll_5cee61b265a79','pll_5cee61b265a79',0),(74,'pll_5cee9a97040f2','pll_5cee9a97040f2',0),(75,'pll_5cee9a99a1eeb','pll_5cee9a99a1eeb',0),(79,'Advertisers','advertisers',0),(80,'pll_5cf0f237b1604','pll_5cf0f237b1604',0),(83,'Publishers','publishers',0),(84,'pll_5cf0f50f91aa0','pll_5cf0f50f91aa0',0),(85,'Creative_Formats','creative_formats',0),(86,'pll_5cf10f1294d75','pll_5cf10f1294d75',0),(87,'pll_5cf65ec05df40','pll_5cf65ec05df40',0),(88,'pll_5cf65ef8abbf4','pll_5cf65ef8abbf4',0),(90,'pll_5cf78c19a193e','pll_5cf78c19a193e',0),(91,'pll_5cf78cb6858af','pll_5cf78cb6858af',0),(92,'pll_5cf7a7b106474','pll_5cf7a7b106474',0),(93,'pll_5cf7a97c7e313','pll_5cf7a97c7e313',0),(94,'pll_5cf7aa093158a','pll_5cf7aa093158a',0),(95,'pll_5cf7aa5c637ef','pll_5cf7aa5c637ef',0),(96,'pll_5cf7aa81cd9c2','pll_5cf7aa81cd9c2',0),(97,'pll_5cf7aacd3dc2a','pll_5cf7aacd3dc2a',0),(98,'pll_5cf7aaf7164aa','pll_5cf7aaf7164aa',0),(99,'pll_5cf7ab29c5667','pll_5cf7ab29c5667',0),(100,'pll_5cf7ab69c1ae8','pll_5cf7ab69c1ae8',0),(101,'pll_5cf7aba34bbc0','pll_5cf7aba34bbc0',0),(102,'pll_5cf7abcd90699','pll_5cf7abcd90699',0),(103,'pll_5cf7ac0b5f1e2','pll_5cf7ac0b5f1e2',0),(104,'pll_5cf7ac385a125','pll_5cf7ac385a125',0),(105,'pll_5cf7ac6180d4f','pll_5cf7ac6180d4f',0),(106,'pll_5cf7ac90bd6ef','pll_5cf7ac90bd6ef',0),(107,'pll_5cf7acd02d2c4','pll_5cf7acd02d2c4',0),(109,'TEST','test',0),(110,'pll_5cff5e6a198e0','pll_5cff5e6a198e0',0),(111,'pll_5d035cf76c683','pll_5d035cf76c683',0),(112,'Advertisers-وكالات الإعلان','advertisers-%d9%88%d9%83%d8%a7%d9%84%d8%a7%d8%aa-%d8%a7%d9%84%d8%a5%d8%b9%d9%84%d8%a7%d9%86',0),(114,'Publishers-دور النشر','publishers-%d8%af%d9%88%d8%b1-%d8%a7%d9%84%d9%86%d8%b4%d8%b1',0),(116,'Cases-Ad-Ar','cases-ad-ar',0),(118,'Cases-Pu-Ar','cases-pu-ar',0),(120,'testtt','testtt',0),(121,'pll_5d1f1aae4c138','pll_5d1f1aae4c138',0);
/*!40000 ALTER TABLE `wp_terms` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-08 15:13:29
