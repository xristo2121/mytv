-- MySQL dump 10.13  Distrib 5.7.16, for Win64 (x86_64)
--
-- Host: 163.172.69.8    Database: projectagora_db
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_taxonomy`
--

LOCK TABLES `wp_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_term_taxonomy` VALUES (3,3,'category','',0,14),(6,6,'nav_menu','',0,14),(7,7,'nav_menu','',0,11),(13,13,'category','',0,1),(15,15,'language','a:3:{s:6:\"locale\";s:5:\"en_US\";s:3:\"rtl\";i:0;s:9:\"flag_code\";s:2:\"us\";}',0,299),(16,16,'term_language','',0,12),(17,17,'term_translations','a:2:{s:2:\"en\";i:13;s:2:\"ar\";i:22;}',0,2),(19,19,'term_translations','a:2:{s:2:\"en\";i:3;s:2:\"ar\";i:114;}',0,2),(20,20,'language','a:3:{s:6:\"locale\";s:2:\"ar\";s:3:\"rtl\";i:1;s:9:\"flag_code\";s:4:\"arab\";}',0,17),(21,21,'term_language','',0,6),(22,22,'category','',0,0),(25,25,'nav_menu','',0,3),(32,32,'category','',3,0),(33,33,'term_translations','a:2:{s:2:\"en\";i:32;s:2:\"ar\";i:118;}',0,2),(35,35,'nav_menu','',0,0),(36,36,'nav_menu','',0,2),(37,37,'nav_menu','',0,2),(38,38,'nav_menu','',0,3),(39,39,'nav_menu','',0,1),(40,40,'category','',0,14),(41,41,'term_translations','a:2:{s:2:\"en\";i:40;s:2:\"ar\";i:112;}',0,2),(42,42,'category','',40,1),(43,43,'term_translations','a:2:{s:2:\"en\";i:42;s:2:\"ar\";i:116;}',0,2),(44,44,'category','',40,0),(45,45,'term_translations','a:1:{s:2:\"en\";i:44;}',0,1),(46,46,'category','',3,0),(47,47,'term_translations','a:1:{s:2:\"en\";i:46;}',0,1),(48,48,'post_tag','',0,24),(49,49,'term_translations','a:1:{s:2:\"en\";i:48;}',0,1),(50,50,'post_tag','',0,16),(51,51,'term_translations','a:1:{s:2:\"en\";i:50;}',0,1),(56,56,'post_translations','a:2:{s:2:\"ar\";i:24202;s:2:\"en\";i:23106;}',0,2),(57,57,'nav_menu','',0,3),(58,58,'nav_menu','',0,8),(59,59,'nav_menu','',0,11),(60,60,'post_translations','a:2:{s:2:\"ar\";i:24284;s:2:\"en\";i:23237;}',0,2),(61,61,'post_translations','a:2:{s:2:\"ar\";i:24289;s:2:\"en\";i:10;}',0,2),(62,62,'nav_menu','',0,2),(64,64,'post_translations','a:2:{s:2:\"ar\";i:24313;s:2:\"en\";i:3;}',0,2),(65,65,'post_translations','a:2:{s:2:\"ar\";i:24345;s:2:\"en\";i:24310;}',0,2),(66,66,'post_translations','a:2:{s:2:\"ar\";i:24356;s:2:\"en\";i:23213;}',0,2),(67,67,'post_translations','a:1:{s:2:\"en\";i:23250;}',0,1),(68,68,'post_translations','a:2:{s:2:\"ar\";i:24365;s:2:\"en\";i:23899;}',0,2),(69,69,'post_translations','a:2:{s:2:\"ar\";i:24475;s:2:\"en\";i:23902;}',0,2),(70,70,'post_translations','a:2:{s:2:\"ar\";i:24478;s:2:\"en\";i:23942;}',0,2),(71,71,'post_translations','a:2:{s:2:\"ar\";i:24481;s:2:\"en\";i:23949;}',0,2),(72,72,'post_translations','a:2:{s:2:\"ar\";i:24484;s:2:\"en\";i:23951;}',0,2),(73,73,'post_translations','a:2:{s:2:\"ar\";i:24487;s:2:\"en\";i:23239;}',0,2),(74,74,'post_translations','a:2:{s:2:\"ar\";i:24534;s:2:\"en\";i:23122;}',0,2),(75,75,'post_translations','a:2:{s:2:\"ar\";i:24535;s:2:\"en\";i:23457;}',0,2),(79,79,'post_tag','',0,16),(80,80,'term_translations','a:1:{s:2:\"en\";i:79;}',0,1),(83,83,'post_tag','',0,6),(84,84,'term_translations','a:1:{s:2:\"en\";i:83;}',0,1),(85,85,'post_tag','',0,11),(86,86,'term_translations','a:1:{s:2:\"en\";i:85;}',0,1),(87,87,'post_translations','a:2:{s:2:\"ar\";i:24864;s:2:\"en\";i:23181;}',0,2),(88,88,'post_translations','a:2:{s:2:\"ar\";i:24863;s:2:\"en\";i:23177;}',0,2),(90,90,'post_translations','a:1:{s:2:\"en\";i:23303;}',0,1),(91,91,'post_translations','a:1:{s:2:\"en\";i:23252;}',0,1),(92,92,'post_translations','a:2:{s:2:\"ar\";i:24936;s:2:\"en\";i:24929;}',0,2),(93,93,'post_translations','a:2:{s:2:\"ar\";i:24939;s:2:\"en\";i:24932;}',0,2),(94,94,'post_translations','a:2:{s:2:\"ar\";i:24946;s:2:\"en\";i:24931;}',0,2),(95,95,'post_translations','a:2:{s:2:\"ar\";i:24949;s:2:\"en\";i:24620;}',0,2),(96,96,'post_translations','a:2:{s:2:\"ar\";i:24952;s:2:\"en\";i:24622;}',0,2),(97,97,'post_translations','a:2:{s:2:\"ar\";i:24956;s:2:\"en\";i:24624;}',0,2),(98,98,'post_translations','a:2:{s:2:\"ar\";i:24959;s:2:\"en\";i:24626;}',0,2),(99,99,'post_translations','a:2:{s:2:\"ar\";i:24962;s:2:\"en\";i:24628;}',0,2),(100,100,'post_translations','a:2:{s:2:\"ar\";i:24965;s:2:\"en\";i:24630;}',0,2),(101,101,'post_translations','a:2:{s:2:\"ar\";i:24968;s:2:\"en\";i:24632;}',0,2),(102,102,'post_translations','a:2:{s:2:\"ar\";i:24970;s:2:\"en\";i:24634;}',0,2),(103,103,'post_translations','a:2:{s:2:\"ar\";i:24972;s:2:\"en\";i:24636;}',0,2),(104,104,'post_translations','a:2:{s:2:\"ar\";i:24974;s:2:\"en\";i:24638;}',0,2),(105,105,'post_translations','a:2:{s:2:\"ar\";i:24976;s:2:\"en\";i:24640;}',0,2),(106,106,'post_translations','a:2:{s:2:\"ar\";i:24978;s:2:\"en\";i:24642;}',0,2),(107,107,'post_translations','a:2:{s:2:\"ar\";i:24980;s:2:\"en\";i:24644;}',0,2),(109,109,'post_tag','',0,0),(110,110,'term_translations','a:1:{s:2:\"ar\";i:109;}',0,1),(111,111,'post_translations','a:2:{s:2:\"ar\";i:25206;s:2:\"en\";i:25200;}',0,2),(112,112,'category','',0,1),(114,114,'category','',0,0),(116,116,'category','',112,1),(118,118,'category','',114,0),(120,120,'nav_menu','',0,0),(121,121,'post_translations','a:2:{s:2:\"ar\";i:25800;s:2:\"en\";i:23248;}',0,2);
/*!40000 ALTER TABLE `wp_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-08 15:13:26
